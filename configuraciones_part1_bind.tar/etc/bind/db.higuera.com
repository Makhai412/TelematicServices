$TTL    604800
@       IN      SOA     ns1.higuera.com. admin.higuera.com. (
                              2         ; Serial
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
@       IN      NS      ns1.higuera.com.
ns1     IN      A       192.168.50.3

