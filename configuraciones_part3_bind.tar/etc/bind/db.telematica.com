;
; BIND data file for local loopback interface
;
$TTL	604800
@	IN	SOA	telematica.com. root.telematica.com. (
			      2		; Serial
			 604800		; Refresh
			  86400		; Retry
			2419200		; Expire
			 604800 )	; Negative Cache TTL
;
@	IN	NS	ns.telematica.com.
ns	IN	A	192.168.90.3
www	IN	CNAME	ns
